import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Post from 'App/Models/Post'

export default class PostsController {
  public async index({view}: HttpContextContract) {
    const posts = await Post.query().preload('user')
    
    return view.render('posts/index', {posts})
  }

  public async create({view}: HttpContextContract) {
    return view.render('posts/create')
  }

  public async store({request}: HttpContextContract) {
    const dados = request.only(['userId', 'text'])
    await Post.create(dados)    
  }

  public async show({}: HttpContextContract) {}

  public async edit({}: HttpContextContract) {}

  public async update({}: HttpContextContract) {}

  public async destroy({}: HttpContextContract) {}
}
